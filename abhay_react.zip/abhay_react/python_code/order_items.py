orderList = [
        {'name':'Red Bull 125ml', 'price':130},
        {'name':'Tropicana', 'price':120},
        {'name':'Whisky 1oz', 'price':1600},
        {'name':'Nachos', 'price':200},
        {'name':'Chicken rice bowl', 'price':816},
        {'name':'Tacos', 'price':1452}
    ]


"""
orderList = [
        {'name':'Red Bull 125ml', 'price':130},
        {'name':'Tropicana', 'price':120},
        {'name':'Whisky 1oz', 'price':1600},
        {'name':'Sprit', 'price':100},
        {'name':'Red wine', 'price':2700},
        {'name':'MONSTER 350ml', 'price':120},
        {'name':'STORM', 'price':120},
        {'name':'C4 250ml', 'price':1000},
        {'name':'Nachos', 'price':200},
        {'name':'Tacos', 'price':1452},
        {'name':'Chicken rice bowl', 'price':816},
        {'name':'Paneer Malai Chaap', 'price':650},
        {'name':'>Kadai Paneer', 'price':540},
        {'name':'Chilli Paneer', 'price':550},
        {'name':'Chocolate cake', 'price':260},
        {'name':'NY cheesecake', 'price':692},
        {'name':'Apple pie', 'price':6466},
        {'name':'Fruit cake', 'price':640},
        {'name':'Sopaipillas', 'price':6467},
        {'name':'Creamy Caramel Flan', 'price':200},
        {'name':'Shortcut Tres Leches Cake', 'price':300},
        {'name':'Pressure-Cooker Pumpkin Flans', 'price':644}
    ]
"""
